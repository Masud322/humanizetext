# HumanizeText

A simple Next.js AI text humanizer. Maximum 500 words per request.

## Run locally
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and add your Gemini API key as `GEMINI_API_KEY`.
4. Run `npm run dev`.

## Deploy on Vercel
1. Upload this project to a GitHub repository.
2. Import the repository into Vercel.
3. Add `GEMINI_API_KEY` in Vercel Project Settings → Environment Variables.
4. Deploy.

Keep your Gemini API key private. Never put it in client-side code or commit it to GitHub. Free-tier quotas and availability can change.
