import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "HumanizeText", description: "AI text humanizer" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}