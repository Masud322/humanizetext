export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const { text } = await request.json();
    if (typeof text !== "string" || !text.trim()) {
      return Response.json({ error: "Please provide text to humanize." }, { status: 400 });
    }
    const wordCount = text.trim().split(/\s+/).length;
    if (wordCount > 500) {
      return Response.json({ error: "Maximum 500 words per request." }, { status: 400 });
    }
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return Response.json({ error: "Server API key is not configured." }, { status: 500 });

    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: "Rewrite the user's text so it reads naturally, clearly, and fluently while preserving its original meaning, facts, and tone. Do not add claims or change meaning. Return only the rewritten text." }] },
        contents: [{ role: "user", parts: [{ text }] }],
        generationConfig: { temperature: 0.7 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return Response.json({ error: data.error?.message || "Gemini request failed." }, { status: response.status });
    }
    const result = data.candidates?.[0]?.content?.parts?.map((p: {text?: string}) => p.text || "").join("").trim();
    if (!result) return Response.json({ error: "No text was returned. Please try again." }, { status: 502 });
    return Response.json({ text: result });
  } catch {
    return Response.json({ error: "Invalid request. Please try again." }, { status: 400 });
  }
}