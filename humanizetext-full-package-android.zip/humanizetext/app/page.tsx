"use client";
import { useState } from "react";

const MAX_WORDS = 500;
export default function Home() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const words = input.trim() ? input.trim().split(/\s+/).length : 0;

  async function humanize() {
    if (!input.trim()) { setError("Please enter some text first."); return; }
    if (words > MAX_WORDS) { setError("Please keep your text within 500 words."); return; }
    setBusy(true); setError(""); setOutput("");
    try {
      const res = await fetch("/api/humanize", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: input })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong.");
      setOutput(data.text || "");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed. Please try again.");
    } finally { setBusy(false); }
  }

  return <main className="wrap">
    <header><div className="logo">H<span>•</span></div><div><h1>HumanizeText</h1><p>Make your writing sound more natural</p></div></header>
    <section className="hero"><span className="tag">AI TEXT HUMANIZER</span><h2>Humanize your text</h2><p>Rewrite AI-generated text into clear, natural-sounding writing.</p></section>
    <section className="panel">
      <div className="panelHead"><strong>Your text</strong><span>{words}/{MAX_WORDS} words</span></div>
      <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Paste your text here (maximum 500 words)..." />
      <div className="actions"><button className="primary" onClick={humanize} disabled={busy || !input.trim() || words > MAX_WORDS}>{busy ? "Humanizing..." : "✨ Humanize Text"}</button><button className="clear" onClick={() => {setInput("");setOutput("");setError("");}}>Clear</button></div>
      {error && <p className="error">{error}</p>}
    </section>
    {output && <section className="panel result"><div className="panelHead"><strong>Humanized result</strong><button className="copy" onClick={() => navigator.clipboard.writeText(output)}>Copy</button></div><div className="output">{output}</div></section>}
    <footer>Simple, natural writing assistance · Maximum 500 words per request</footer>
  </main>;
}